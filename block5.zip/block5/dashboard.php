<!DOCTYPE html>
<html lang="en">
    <head>
<meta charset="utf-8">
        <meat name="viewport" content="width=device-width, initial-sacle=1">
        <link rel="stylesheet" href="bootstrap.min.css">
</head>
    <body style="background-color:black;">
        <div class="container">
            <div class="welcome">
                <h2>Welcome to the Dashboard!</h2>
                <p>This is your dashboard page. You can customize it further to display relevant information and function</p>
                <p>Logout if you want to end your session</p>
                <a href="logout.php" class="btn btn-danger" >Logout</a>
            </div>
        </div>
    </body>
</html>
<style>
    .welcome{
        margin-left:30%;
        color:white;
    }
    h2{
        margin-left:15%;
    }
    </style>