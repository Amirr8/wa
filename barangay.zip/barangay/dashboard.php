<?php require 'connection.php' ?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome Admin</title>
</head>

<body class="d-flex">

    <!-- Sidebar -->
    <div class="min-vh-100  d-flex flex-column" style="border-right: 3px solid green; width: 17%; position:fixed; ">
        <div class=" d-flex flex-column align-items-center justify-content-start" id="sidebar">
            <div id="logo" class="w-100 text-center h-100">
                <img src="image.png" alt="logo" class="logo-img">
                <h2>Brgy.</h2>
            </div>
            <div id="sidebar-buttons" class="w-100 mt-2">
                <button class=" sidebar-btn py-3  w-100 " ">Dashboard</button>
                <button class=" sidebar-btn py-3 w-100 " >Manage Residents</button>
                <button class=" sidebar-btn py-3 w-100 " >Manage Complaints</button>
                <button class=" sidebar-btn py-3 w-100 " >Manage Officials</button>
                <button class=" sidebar-btn py-3 w-100 " >View Reports</button>
                <button class=" sidebar-btn py-3 w-100 " >Log out</button>
            </div>

        </div>
    </div>

    <div class=" min-vh-100" style="width: 17%">
            </div>

            <div class="min-vh-100 " style="width: 83%">
                <div class="container d-flex flex-column align-items-center  justify-content-center">
                    <div id="title" class="py-3">
                        <div class="text-center">
                            <h1 class="display-4">Welcome Admin!</h1>
                            <h2 class="display-5">Barangay - Information System</h2>
                        </div>
                    </div>
                    <div id="dashboard-contents" class=" container-md w-100 d-flex align-items-center justify-content-center " style="min-height: 73svh;">

                        <div class=" container-md align-items-center justify-content-center  row row-cols-3 h-100 ">
                            <div class="dashboard-content border border-2 border-dark py-3 text-center  mb-3  col">
                                <p>Total Households</p>
                                <P>0</P>
                            </div>
                            <div class="dashboard-content border border-2 border-dark py-3 text-center mb-3 col">
                                <p>Total Population</p>
                                <P>0</P>
                            </div>
                            <div class="dashboard-content border border-2 border-dark py-3 text-center mb-3 col">
                                <p>Male</p>
                                <P>0</P>
                            </div>
                            <div class="dashboard-content border border-2 border-dark py-3 text-center mb-3 col">
                                <p>Female</p>
                                <P>0</P>
                            </div>
                            <div class="dashboard-content border border-2 border-dark py-3 text-center mb-3 col">
                                <p>Children</p>
                                <P>0</P>
                            </div>
                            <div class="dashboard-content border border-2 border-dark py-3 text-center mb-3 col">
                                <p>Senior</p>
                                <P>0</P>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
</body>

</html>
<style>
    #logo {
        height: 15svh;
    }

    .dashboard-content {
        width: 30%;
        margin-right: 4;
    }

    .dashboard-content p {
        font-size: 1.2rem;
        font-weight: bold;
    }

    .sidebar-btn {
        border: 1px solid gray;
        border-right: 0;
        border-bottom: 0;
        background: none;
        font-size: 1.2rem;
    }

    .sidebar-btn:last-child {
        border-bottom: 1px solid gray
    }

    .logo-img {
        width: 60%;
    }
</style>