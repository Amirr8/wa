<!DOCTYPE html>
<html>
<head>
  <title>Login</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
</head>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
<?php include 'connection.php' ?>
<?php 

  if(isset($_POST['submit'])){
    $users = $_POST['user'];
    $passs = $_POST['pass'];
    $fnames = $_POST['fname'];
    $mnames = $_POST['mname'];
    $lnames = $_POST['lname'];
    $pos = 'Employee';

    $query = "SELECT * FROM `users` WHERE `Username` = '$users'";
    $stmts = $conn->prepare($query);
    $stmts->execute();
    $result = $stmts->get_result();
    $row = $result->fetch_assoc();

    if($users == @$row['Username']){

      echo '<p class="text-danger">User already exist! Please try another username!</p>';


    }else{

    $sql = "INSERT INTO `users`( `Username`, `Password`, `Fname`, `Mname`, `Lname`, `Position`) VALUES (?,?,?,?,?,?)";
    $stmt = $conn->prepare($sql);
    $stmt -> bind_param("ssssss",$users,$passs,$fnames,$mnames,$lnames,$pos);
    $stmt->execute();
      echo 'Registered Successfully.';

  }
}
?>
  <h2>SIGN UP!</h2>
  <form action="" method="post" class="form-group">
      <label for="user">Username: <span class="required-indicator">
      <input type="text" name="user" id="user" placeholder="Username" required><br><br>

      <label for="pass">Password: <span class="required-indicator">
      <input type="password" name="pass" id="pass" placeholder="Password" required><br><br>

      <label for="fname">Firstname: <span class="required-indicator">
      <input type="text" name="fname" id="fname" placeholder="Firstname" required><br><br>

      <label for="mname">Midname: <span class="required-indicator">
      <input type="text" name="mname" id="mname" placeholder="Midname" required><br><br>

      <label for="lname">Lastname: <span class="required-indicator">
      <input type="text" name="lname" id="lname" placeholder="Lastname" required><br><br>
      <input type="checkbox" onclick="myFunction()">Show Password<br><br>

        <button type="submit" name="submit" class="btn btn-success">REGISTER</button><br><br>
        <p>Already have an account? <a href="index.php" class="btn btn-outline-info">Login Here</a></p>
        </div>
</div>
    </form>
</div>
</div>
<body>
  <html>