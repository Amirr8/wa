<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <title>Document</title>
</head>
<body>
    

<?php include 'connection.php'?>

<?php
 $myguest_id = isset($_GET['myguest_id']) ? $_GET['myguest_id'] : null;
 if(!$myguest_id){
     die('Invalid ID');

 }

 $sql = "SELECT * FROM `myguest` WHERE `myguest_id`=$myguest_id";
 $stmt = $conn->query($sql);
 $row = $stmt->fetch_assoc();

    if($_SERVER["REQUEST_METHOD"] == "POST"){
        $myguest_id = $_POST['myguest_id'];
        $first_name = $_POST['fname'];
        $last_name = $_POST['lname'];
        $email = $_POST['email'];
        $reg_date = $_POST['reg_date'];

    
       
            $sql1 = "UPDATE myguest SET fname ='$first_name', lname='$last_name', reg_date='$reg_date', email='$email'
            WHERE myguest_id='$myguest_id'";
        

        $stmt = $conn->query($sql1);

        header("Location: dashboard.php");
        exit();
    }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap.css">
    <title>Update Student</title>
</head>
<body class="bg-dark">
    <h1 style="text-align: center; color: white;">Update Student</h1><br><br>
    <div class="for-group" style="display: flex; justify-content: center; align-items: center;">
    <form action="" method="POST" enctype="multipart/form-data" style="color: white;">
        <input type="hidden" name="myguest_id" value="<?php echo $row['myguest_id'];?>">
        <label for="">First Name:</label>
        <input type="text" name="fname" value="<?php echo $row['fname'];?>" required><br><br>
        <label for="">Middle Name:</label>
        <input type="text" name="lname" value="<?php echo $row['lname'];?>"><br><br>
        <label for="">Last Name:</label>
        <input type="text" name="email" value="<?php echo $row['email'];?>"><br><br>
        <label for="">Address:</label>
        <input type="text" name="reg_date" value="<?php echo $row['reg_date'];?>"><br><br>
        <label for="">Contact Number:</label>
        <input type="submit" value="Update Student">
    </form>
    </div>
    <br><br><br>
    <a href="dashboard.php" class="btn btn-outline-info">Back</a>
</body>
</html>