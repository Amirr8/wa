
<?php include 'connection.php' ?>

<?php




    $myguest_id = isset($_GET['myguest_id']) ? $_GET['myguest_id'] : null;
    if(!$myguest_id){
        die('Invalid ID');
    }

    $sql = "DELETE FROM myguest WHERE myguest_id=$myguest_id";
    $conn->query($sql);

    header("Location: dashboard.php");
    exit();
?>
