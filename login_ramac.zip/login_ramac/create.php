<?php require 'connection.php';


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $firstname = $_POST['fname'];
    $lastname = $_POST['lname'];
    $email = $_POST['email'];


    $query = "INSERT INTO `myguest`( `fname`, `lname`, `email` ) VALUES ('$firstname','$lastname','$email')";
    $conn->query($query);
    header("location:dashboard.php");

}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <title>Add Student</title>
</head>

<body class="bg-dark">
    <h1 style="text-align: center; color: white;">Add Student</h1><br><br>
    <div class="for-group" style="display: flex; justify-content: center; align-items: center;">
        <form action="" method="POST" enctype="multipart/form-data" style="color: white;">
            <label for="">First Name: </label>
            <input type="text" name="fname" required><br><br>
            <label for="">Last name: </label>
            <input type="text" name="lname" required><br><br>
            <label for="">Email: </label>
            <input type="text" name="email" required><br><br>
            <input type="submit" value="Add Student">
        </form>
    </div>
    <br><br><br>
    <a href="dashboard.php" class="btn btn-outline-info">Back</a>
</body>

</html>