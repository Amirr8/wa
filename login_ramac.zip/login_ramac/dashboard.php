<?php include 'connection.php' ?>
<?php 
$sql="SELECT * FROM myguest";
$stmt=$conn->query($sql);


?>
<!DOCTYPE html>
<html>
	<body>
<head>
	<title>Login</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
</head>
		
		<div class="container-fluid">
<div class="row">
	<div class="col-3">

	</div>
	<div class="col-6">
	<table border="5" class="table table-white" style="margin:30px;">
	<b>
		<th>ID</th>
		<th>First Name</th>
		<th>lastname</th>
		<th>email</th>
		<th>reg_date</th>
		<th>action</th>




<?php
	if($stmt->num_rows > 0){
		while($row = $stmt-> fetch_assoc()){
			echo "<tr>";
			echo "<td>".$row["myguest_id"]."</td>";
			echo "<td>".$row["fname"]."</td>";
			echo "<td>".$row["lname"]."</td>";
			echo "<td>".$row["email"]."</td>";
			echo "<td>".$row["reg_date"]."</td>";
			echo "<td><a href='update.php?myguest_id=".$row["myguest_id"]."'  class='btn btn-info'>Edit</a> || <a href='delete.php?myguest_id=".$row["myguest_id"]."'  class='btn btn-danger'>Delete</a></td>";
			echo "</tr>";
		}
	} else{
		echo "<tr><td colspan = '7'> No records found</td></tr>";
	}
?>
	</b>
</table>
	
	</div>
	<div class="col-3">
	<form action="" method="POST"><br>
	<a href="logout.php" name="" value="logout" class="btn btn-danger" onclick="return confirm('Are you sure you want to logout?')" style="margin-left:3cm;">Logout</a>
</form>
	</div>
</div>

		</div>
		

<body>
	<html>