<!DOCTYPE html>
<?php include 'connection.php' ?>
<?php
$sql = "SELECT * FROM myguest";
$stmt = $conn->query($sql);


?>

<html>

<head>
	<title>Login</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
		integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
		integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
</head>

<body style="background-color:black;">
	<!-- <table >






	</table>
	<a href="logout.php" name="" value="logout" class="btn btn-danger"
		onclick="return confirm('Are you sure you want to logout?')">Logout</a>



	

	</table> -->
	<div class="container min-vh-100  flex-column d-flex align-items-end justify-content-center">
		<a href="create.php" class="btn btn-outline-info " style="margin-bottom:10px;">Add New Student</a>
		<table class="table table-dark align-middle table-hover h-60">
			<thead>
				<tr>

					<th>ID</th>
					<th>First Name</th>
					<th>Last Name</th>
					<th>Email</th>
					<th>Reg Date</th>
					<th>Action</th>
				</tr>
			</thead>
			<tbody class="table-group-divider">
				<?php
				if ($stmt->num_rows > 0) {
					while ($row = $stmt->fetch_assoc()) {
						echo "<tr style='height: 100px'>";
						echo "<td>" . $row["myguest_id"] . "</td>";
						echo "<td>" . $row["fname"] . "</td>";
						echo "<td>" . $row["lname"] . "</td>";
						echo "<td>" . $row["email"] . "</td>";
						echo "<td>" . $row["reg_date"] . "</td>";
						echo "<td><a href='update.php?myguest_id=" . $row["myguest_id"] . "'  class='btn btn-info'>Edit</a> || <a href='delete.php?myguest_id=" . $row["myguest_id"] . "'  class='btn btn-danger'>Delete</a></td>";
						echo "</tr>";
					}
				} else {
					echo "<tr><td colspan = '7'> No records found</td></tr>";
				}
				?>
			</tbody>

		</table>
		<a href="logout.php" name="" value="logout" class="btn btn-danger"
			onclick="return confirm('Are you sure you want to logout?')">Logout</a>

	</div>



</body>
<html>